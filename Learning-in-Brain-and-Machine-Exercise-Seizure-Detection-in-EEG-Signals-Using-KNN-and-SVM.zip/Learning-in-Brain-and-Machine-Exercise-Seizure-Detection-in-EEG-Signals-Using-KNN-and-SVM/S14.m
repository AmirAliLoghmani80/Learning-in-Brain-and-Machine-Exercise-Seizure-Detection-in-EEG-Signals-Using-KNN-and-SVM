clc;
clear;
close all;
%%%% Sub14
folderPath = 'D:\ترم 7\Courses\learning\hw4\Sub14\WS14\';
baseFileName = 'chb14_';
s_ws_raw = file_read(folderPath, baseFileName);
s_ws_start_points = [1986 ,1911, 1838, 3239, 1039, 2833];
s_ws = epoch_selection_ws( s_ws_start_points , s_ws_raw);
folderPath = 'D:\ترم 7\Courses\learning\hw4\Sub14\WOS14\';
s_wos_raw = file_read(folderPath, baseFileName);
s_wos = epoch_selection_wos( minute_selection_wos(length(s_ws_start_points),s_wos_raw) , s_wos_raw);
s_ws_feature_extraction = feature_extraction_matrix(s_ws);
s_wos_feature_extraction = feature_extraction_matrix(s_wos);
[s_wos_test_feat_ex,s_ws_test_feat_ex,s_wos_train_feat_ex,s_ws_train_feat_ex] = train_test_split(s_ws_feature_extraction,s_wos_feature_extraction,2);
[s_ws_train_features,s_wos_train_features,indexes_s] = feature_selection_total(s_ws_train_feat_ex,s_wos_train_feat_ex);
s_ws_test_features = s_ws_test_feat_ex(:,indexes_s);
s_wos_test_features = s_wos_test_feat_ex(:,indexes_s);

s_ws_train_labels = ones(4, 1);
s_wos_train_labels = zeros(4, 1);
s_ws_test_labels = ones(2, 1);
s_wos_test_labels = zeros(2, 1);

s = vertcat(s_ws_train_features, s_wos_train_features);
t = vertcat(s_ws_train_labels, s_wos_train_labels);

s_test = vertcat(s_ws_test_features, s_wos_test_features);
t_test = vertcat(s_ws_test_labels, s_wos_test_labels);

knnClassifier = fitcknn(s, t, 'NumNeighbors', 2); 
predictions_knn = predict(knnClassifier, s_test);
accuracy_knn = sum(predictions_knn == t_test) / length(t_test);
[sensitivity_knn, specificity_knn] = calculateSensitivitySpecificity(t_test, predictions_knn);


svmClassifier = fitcsvm(s, t, 'KernelFunction', 'linear');
predictions_svm = predict(svmClassifier, s_test);
accuracy_svm = sum(predictions_svm == t_test) / length(t_test);
[sensitivity_svm, specificity_svm] = calculateSensitivitySpecificity(t_test, predictions_svm);


%%%%%%%%%%%%%% 
%%%%%Functions
function outputVariable = file_read(folderPath, baseFileName)
%     folderPath = 'D:\ترم 7\Courses\learning\hw4\Sub1\WS1\';
%     baseFileName = 'chb01_';
    edfFiles = dir(fullfile(folderPath, [baseFileName, '*.edf']));
    s_ws_raw = cell(1, numel(edfFiles));
    for i = 1:numel(edfFiles)
        filePath = fullfile(folderPath, edfFiles(i).name);
        s_ws_raw{i} = edfread(filePath);
    end
    outputVariable = s_ws_raw;
end

function outputVariable = epoch_selection_ws(start_points, s_ws_raw)
    l = length(start_points); 
    s_ws = cell(l, 34);
%     s1_ws_start_points = [2996, 1467, 1732, 1015, 1720, 1862];
    for j=1:l
        for i=1:34
            s = i .* 16;
            e = (i-1) .* 16;
            startTime = seconds(start_points(j) - s);
            endTime = seconds(start_points(j) - e);
            timeRange = timerange(startTime, endTime);
            temp = s_ws_raw(j);
            temp = temp{1};
            s_ws{j,i} = table2array(temp(timeRange, :));
        end
    end
    outputVariable = flip(s_ws,2);
end

function outputVariable = minute_selection_wos(l,s_wos_raw)
    timetableLength = height(s_wos_raw{1});
%     last_possible_starts = timetableLength - 540;
    first_possible_start = 540;
    
    %     s1_ws_start_points = [2996, 1467, 1732, 1015, 1720, 1862];
    lowerBound = first_possible_start;
    upperBound = timetableLength;

    % Generate n non-similar random numbers
    randomNumbers = randperm(upperBound - lowerBound + 1, l) + lowerBound - 1;
    outputVariable = randomNumbers;
end


function outputVariable = epoch_selection_wos(start_points, s_wos_raw)
    l = length(start_points); 
    s_wos = cell(l, 34);
%     s1_ws_start_points = [2996, 1467, 1732, 1015, 1720, 1862];
    for j=1:l
        for i=1:34
            s = i .* 16;
            e = (i-1) .* 16;
            startTime = seconds(start_points(j) - s);
            endTime = seconds(start_points(j) - e);
            timeRange = timerange(startTime, endTime);
            temp = s_wos_raw;
            temp = temp{1};
            s_wos{j,i} = table2array(temp(timeRange, :));
        end
    end
    outputVariable = flip(s_wos,2);
end


function outputVariable = feature_extraction_matrix(s_ws_total)
%     l = length(s_ws_total);
    l = size(s_ws_total, 1);
    array = zeros(l,4760);
    for j=1:l
       array(j,:) = featureExtraction(s_ws_total(j,:)); 
        
    
    end


    outputVariable = array;
end

function outputVariable = featureExtraction(s_ws)

%     s1_ws_start_points = [2996, 1467, 1732, 1015, 1720, 1862];
    features = zeros(1,4760);
    t = 0;
    for j=1:34
         a = s_ws;
         b = a(1,j);
         c = b{1};
        for i=1:23
            d = c(:,1);
            concatenatedArray = vertcat(d{:});
            
            t = t + 1;
            shannon = shannonEntropy(concatenatedArray);
            features(1,t) = shannon;
            
            t = t + 1;
            average = mean(concatenatedArray);
            features(1,t) = average;   
            
            t = t + 1;
            minValue = min(concatenatedArray);
            features(1,t) = minValue;
            
            t = t + 1;
            maxValue = max(concatenatedArray);
            features(1,t) = maxValue;
            
            t = t + 1;
            stdDev = std(concatenatedArray);
            features(1,t) = stdDev;


        end
    end
    outputVariable = features;
end
function outputVariable = shannonEntropy(concatenatedArray)
fs = 256;
[Pxx, f] = periodogram(concatenatedArray, [], [], fs);
norm_Pxx = Pxx / max(Pxx);
entropy = -sum(norm_Pxx .* log2(norm_Pxx));
outputVariable = entropy;
end

function outputVariable = feature_selection(features)
    null_mean = zeros(1, size(features, 2));
    p_values = zeros(1, size(features, 2));
    for i = 1:size(features, 2)
    [~, p_values(i)] = ttest(features(:, i), null_mean(i));
    end
    alpha = 0.001;
    significant_features = find(p_values < alpha);
    significant_data = features(:, significant_features);
    outputVariable = significant_data;
end
function outputVariable = feature_selection_indexes(features)
    null_mean = zeros(1, size(features, 2));
    p_values = zeros(1, size(features, 2));
    for i = 1:size(features, 2)
    [~, p_values(i)] = ttest(features(:, i), null_mean(i));
    end
    alpha = 0.001;
    significant_features = find(p_values < alpha);
    outputVariable = significant_features;
end 

function [test_set_negatives, test_set_positives, training_set_negatives, training_set_positives] = train_test_split(s_ws, s_wos,num_test)%     folderPath = 'D:\ترم 7\Courses\learning\hw4\Sub1\WS1\';
    l = size(s_ws, 1);
    test_indices_negatives = randperm(l, num_test);
    test_indices_positives = randperm(l, num_test);

    test_set_negatives = s_wos(test_indices_negatives, :);
    test_set_positives = s_ws(test_indices_positives, :);

    training_set_negatives = s_wos(setdiff(1:l, test_indices_negatives), :);
    training_set_positives = s_ws(setdiff(1:l, test_indices_positives), :);


end

function [outputVariable_ws,outputVariable_wos,indexes] = feature_selection_total(features_ws,features_wos)
    combined_array = vertcat(features_ws, features_wos);
    null_mean = zeros(1, size(combined_array, 2));
    p_values = zeros(1, size(combined_array, 2));
    for i = 1:size(combined_array, 2)
    [~, p_values(i)] = ttest(combined_array(:, i), null_mean(i));
    end
    alpha = 0.001;
    significant_features = find(p_values < alpha);
%     significant_data = features(:, significant_features);
    outputVariable_ws = features_ws(:, significant_features);
    outputVariable_wos = features_wos(:, significant_features);
    indexes = significant_features;

end
function [sensitivity, specificity] = calculateSensitivitySpecificity(groundTruth, predictions)
    confusionMatrix = confusionmat(groundTruth, predictions);
    TP = confusionMatrix(1, 1);
    FP = confusionMatrix(2, 1);
    TN = confusionMatrix(2, 2);
    FN = confusionMatrix(1, 2);
    sensitivity = TP / (TP + FN);
    specificity = TN / (TN + FP);
end
